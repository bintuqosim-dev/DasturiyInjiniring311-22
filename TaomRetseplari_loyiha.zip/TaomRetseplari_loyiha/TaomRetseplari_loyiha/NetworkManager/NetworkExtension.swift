//
//  NetworkExtension.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 23.11.2567 (BE).
//

import Foundation

extension Data {
    func decoded<T: Decodable>() throws -> T {
        return try JSONDecoder().decode(T.self, from: self)
    }
}
