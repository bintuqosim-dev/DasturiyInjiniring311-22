//
//  Color.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 23.11.2567 (BE).
//

import SwiftUI

extension Color {
    static let tabbarGray = Color(red: 37/255, green: 37/255, blue: 37/255)
}
