//
//  TaomRetseplari_loyihaApp.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 23.11.2567 (BE).
//

import SwiftUI

@main
struct TaomRetseplari_loyihaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
