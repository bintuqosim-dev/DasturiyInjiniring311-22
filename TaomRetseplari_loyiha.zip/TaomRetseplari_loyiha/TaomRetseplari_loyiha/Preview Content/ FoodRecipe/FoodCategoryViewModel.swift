//
//  FoodCategoryViewModel.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 21.11.2567 (BE).
//

import Foundation
import Combine

class FoodCategoryViewModel: ObservableObject {
    @Published var meals: [Meal] = []

    func fetchMeals(for category: String) {
        NetworkManager.shared.fetchCategoryMeals(for: category) { result in
            switch result {
            case .failure(let error):
                print("Failed to fetch meals: \(error)")
            case .success(let response):
                DispatchQueue.main.async {
                    self.meals = response.meals
                }
            }
        }
    }
}

