//
//  ButtonView.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 23.11.2567 (BE).
//

import SwiftUI

struct CategoryButtonStyle: ButtonStyle {
    let color: Color

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(8)
            .background(color)
            .foregroundColor(.white)
            .cornerRadius(5)
    }
}

