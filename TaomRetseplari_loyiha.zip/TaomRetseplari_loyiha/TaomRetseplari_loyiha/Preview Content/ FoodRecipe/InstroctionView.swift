//
//  InstroctionView.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 23.11.2567 (BE).
//

import SwiftUI

struct FoodDetailsInstructionsView: View {
    let meal: DetailedMeal

    var body: some View {
        ScrollView {
            Text(meal.getInstructionsText())
                .padding()
        }
        .navigationTitle("Instructions")
    }
}
