//
//  Food.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 21.11.2567 (BE).
//

import Foundation

struct Meal: Decodable, Hashable, Identifiable {
    let id: String
    let name: String
    let imageUrlString: String
    
    enum CodingKeys: String, CodingKey {
        case id = "idMeal"
        case name = "strMeal"
        case imageUrlString = "strMealThumb"
    }
}

struct MealResponse: Decodable {
    let meals: [Meal]
}


