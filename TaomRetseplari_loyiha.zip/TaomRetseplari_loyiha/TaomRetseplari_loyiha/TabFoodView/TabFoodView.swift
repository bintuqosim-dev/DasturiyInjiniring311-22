//
//  TabFoodView.swift
//  TaomRetseplari_loyiha
//
//  Created by Axmatjonov Madiyorbek on 21.11.2567 (BE).
//

import SwiftUI

struct TabFoodView: View {
    @State private var searchText = ""
   
    var body: some View {
        NavigationView {
            ScrollView {
                VStack {
                    RandomFoodView()
                        .padding(.top, -15)
                    
                    NavigationLink(destination: FoodFeedView()) {
                        VideoPlayerView()
                            .frame(width: 380, height: 450)
                            .padding(.top, -43)
                    }
                }
            }
            .background(Color.black)
        }
        .navigationBarHidden(true)
        .padding(.horizontal, -10)
    }
}

